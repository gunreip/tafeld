<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class StockMovementSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('stock_movements')->insert([
            ['uuid' => Str::uuid(), 'inventory_item_id' => 1, 'type' => 'in', 'quantity' => 10, 'note' => 'Erster Bestand'],
        ]);
    }
}
