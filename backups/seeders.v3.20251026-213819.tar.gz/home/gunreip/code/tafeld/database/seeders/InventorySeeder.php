<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class InventorySeeder extends Seeder
{
    public function run(): void
    {
        DB::table('inventory_items')->insert([
            ['uuid' => Str::uuid(), 'name' => 'Laptop', 'sku' => 'IT-1001', 'quantity' => 10, 'price' => 1299.00],
        ]);
    }
}
