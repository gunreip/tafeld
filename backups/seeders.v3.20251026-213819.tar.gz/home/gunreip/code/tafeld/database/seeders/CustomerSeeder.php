<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class CustomerSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('customers')->insert([
            ['uuid' => Str::uuid(), 'name' => 'Beispielkunde GmbH', 'email' => 'kunde@example.com', 'phone' => '+4912345678'],
        ]);
    }
}
