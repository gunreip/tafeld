<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class EmployeeSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('employees')->insert([
            ['uuid' => Str::uuid(), 'name' => 'Max Mustermann', 'position' => 'Leitung', 'department' => 'Verwaltung', 'entry_date' => '2022-01-01', 'active' => true],
        ]);
    }
}
