<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DocumentSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('documents')->insert([
            [
                'uuid' => Str::uuid(),
                'title' => 'Mitarbeitervertrag',
                'path' => 'storage/private/contracts/vertrag1.pdf',
                'user_id' => 1,
                'encrypted_data' => json_encode(['note' => 'Demodokument']),
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
