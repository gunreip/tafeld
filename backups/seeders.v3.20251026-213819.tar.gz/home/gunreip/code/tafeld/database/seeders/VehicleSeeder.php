<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class VehicleSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('vehicles')->insert([
            ['uuid' => Str::uuid(), 'identifier' => 'B-TAF 123', 'model' => 'Transporter', 'mileage' => 10000],
        ]);
    }
}
