<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class WorkScheduleSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('work_schedules')->insert([
            ['uuid' => Str::uuid(), 'employee_id' => 1, 'work_date' => '2025-10-27', 'start_time' => '08:00', 'end_time' => '16:00'],
        ]);
    }
}
