<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class CashbookSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('cashbook_entries')->insert([
            ['uuid' => Str::uuid(), 'entry_date' => '2025-10-26', 'amount' => 1000.00, 'type' => 'income', 'category' => 'Startkapital'],
        ]);
    }
}
