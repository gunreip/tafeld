<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Services\AuditService;
use Illuminate\Support\Facades\DB;

class AuditSeeder extends Seeder
{
    public function run(): void
    {
        $tables = [
            'employees', 'customers', 'inventory_items', 'stock_movements',
            'cashbook_entries', 'vehicles', 'work_schedules', 'documents'
        ];

        foreach ($tables as $table) {
            $rows = DB::table($table)->get();
            foreach ($rows as $row) {
                AuditService::log('seed_insert', $table, ['id' => $row->id]);
            }
        }
    }
}
